.onAttach <- function(lib, pkg) {
  packageStartupMessage("\nMarClimEX 0.1\nUse marclimex.start() to launch or re-launch the interface.\n")
}
