## Check that climdexInput data structure is valid.
#valid.climdexInput <- function(x) {
#return(TRUE)
#}
setClass("climdexInput",
         representation(data = "list",
                        quantiles = "numeric",
                        namasks = "list",
                        dates = "PCICt",
                        jdays = "numeric",
                        base.range = "PCICt",
                        date.factors = "list",
                        max.missing.days = "numeric")
#         validity=valid.climdexInput
         )

## Creates a filled series given the data, dates, and new date sequence to be used.
create.filled.series <- function(data, data.dates, new.date.sequence) {
  new.data <- rep(NA, length(new.date.sequence))
  data.in.new.data <- (data.dates >= new.date.sequence[1]) & (data.dates <= new.date.sequence[length(new.date.sequence)])
  indices <- floor(as.numeric(data.dates[data.in.new.data] - new.date.sequence[1], units="days")) + 1
  new.data[indices] <- data[data.in.new.data]
  return(new.data)
}

## Get julian day of year
get.jdays <- function(dates) {
  return(as.POSIXlt(dates)$yday + 1)
}

get.years <- function(dates) {
  return(as.POSIXlt(dates)$year + 1900)
}

get.last.monthday.of.year <- function(d, sep="-") {
  if(!is.null(attr(d, "months"))) paste("12", attr(d, "months")[12], sep=sep) else paste("12", "31", sep=sep)
}

## Get NA mask given threshold and split factor
get.na.mask <- function(x, f, threshold) {
  return(c(1, NA)[1 + as.numeric(tapply.fast(is.na(x), f, function(y) { return(sum(y) > threshold) } ))])
}

## Get number of days within range
get.num.days.in.range <- function(x, date.range) {
  return(sum(x >= date.range[1] & x <= date.range[2]))
}

get.var.quantiles <- function(filled.var, date.series, bs.date.range, qtiles=c(0.1, 0.99)) {
  valid.days <- !(is.na(filled.var) | filled.var <= 0)
  bs.days <- sum ( date.series >= bs.date.range[1] & date.series <= bs.date.range[2] )
  inset <- date.series >= bs.date.range[1] & date.series <= bs.date.range[2] & !is.na(filled.var) & valid.days
# if(sum(inset)/bs.days > 
  pq <- quantile(filled.var[inset], qtiles, type=8)
  names(pq) <- paste("q", qtiles * 100, sep="")
  return(pq)
}

number.days.op.threshold <- function(temp, date.factor, threshold, op="<") {
  stopifnot(is.numeric(temp) && is.numeric(threshold) && is.factor(date.factor))
  return(tapply.fast(match.fun(op)(temp, threshold), date.factor, sum, na.rm=TRUE))
}

#' Select blocks of TRUE values of sufficient length.
#' 
#' Produces a sequence of booleans of the same length as input, with sequences
#' of TRUE values shorter than n replaced with FALSE.
#' 
#' This function takes a series of booleans and returns a sequence of booleans
#' of equal length, with all sequences of TRUE of length \code{n} or shorter
#' replaced with sequences of FALSE. NA values are replaced with
#' \code{na.value}.
#' 
#' @param d Sequence of booleans.
#' @param n Longest sequence of TRUE to replace with FALSE.
#' @param na.value Values to replace NAs with.
#' @return A vector of booleans, with the length \code{n} or less sequences of
#' TRUE replaced with FALSE.
#' @keywords ts climate
#' @examples
#' 
#' ## Return only the first sequence of TRUE... second sequence will be FALSE.
#' foo <- select.blocks.gt.length(c(rep(TRUE, 4), FALSE, rep(TRUE, 3)), 3)
#' 
#' @export
select.blocks.gt.length <- function(d, n, na.value=FALSE) {
  stopifnot(is.logical(d), is.numeric(n))

  if(n < 1)
    return(d)

  if(n >= length(d))
    return(rep(FALSE, length(d)))

  d[is.na(d)] <- na.value

  d2 <- Reduce(function(x, y) { return(c(rep(FALSE, y), d[1:(length(d) - y)]) & x) }, 1:n, d)
  return(Reduce(function(x, y) { return(c(d2[(y + 1):length(d2)], rep(FALSE, y)) | x) }, 1:n, d2))
}

#' @title Sum of spell lengths exceeding daily threshold
#' 
#' @description
#' This function returns the number of spells of more than \code{min.length}
#' days which exceed or are below the given threshold.
#' 
threshold.exceedance.duration.index <- function(data, date.factor, thresholds, op=">", min.length=6, spells.can.span.years=TRUE) {
  stopifnot(is.numeric(c(data, thresholds, min.length)), is.factor(date.factor),
            is.function(match.fun(op)),
            min.length > 0)
  f <- match.fun(op)

  if(spells.can.span.years) {
    periods <- select.blocks.gt.length(f(data, thresholds), min.length - 1)
    return(tapply.fast(periods, date.factor, sum))
  } else {
    ## cut to annual series then calculate
    return(tapply.fast(1:length(data), date.factor, function(idx) { sum(select.blocks.gt.length(f(data[idx], thresholds), min.length - 1)) } ) )
  }
}

#' ## Create a climdexInput object from some data already loaded in and
#' ## ready to go.
#' 
#' ## Load the data in.
#' ci <- climdexInput.raw(ec.1018935.tmax$MAX_TEMP,
#' ec.1018935.tmin$MIN_TEMP, ec.1018935.prec$ONE_DAY_PRECIPITATION,
#' tmax.dates, tmin.dates, prec.dates, base.range=c(1971, 2000))
#'
#' @export
climdexInput.raw <- function(var=NULL, var.dates=NULL, base.range=c(1961, 1990), 
                             var.qtiles=c(0.10, 0.90), max.missing.days=c(annual=15, monthly=3), 
                             min.base.data.fraction.present=0.75) {
  ## Make sure all of these arguments are valid...
# check.basic.argument.validity(tmax, tmin, prec, tmax.dates, tmin.dates, prec.dates, base.range, n, tavg, tavg.dates)

  stopifnot(length(max.missing.days) == 2 && all(c("annual", "monthly") %in% names(max.missing.days)))
  stopifnot(is.numeric(min.base.data.fraction.present) && length(min.base.data.fraction.present) == 1)

  d.list=list(var.dates)
  all.dates <- do.call(c, d.list[!sapply(d.list, is.null)])
  last.day.of.year <- get.last.monthday.of.year(all.dates)
  cal <- attr(all.dates, "cal")

  ## Convert base range (in years) to PCICt
  bs.date.range <- as.PCICt(paste(base.range, c("01-01", last.day.of.year), sep="-"), cal=cal)
  bs.date.series <- seq(bs.date.range[1], bs.date.range[2], by="day")

  ## Get dates for normal data
  new.date.range <- as.PCICt(paste(as.numeric(format(range(all.dates), "%Y", tz="GMT")), c("01-01", last.day.of.year), sep="-"), cal=cal)
  date.series <- seq(new.date.range[1], new.date.range[2], by="day")

  ## Factors for dividing data up
  date.factors <- list(annual=factor(format(date.series, format="%Y", tz="GMT")), monthly=factor(format(date.series, format="%Y-%m", tz="GMT")))

  ## Filled data...
  var.list <- c("var")
  present.var.list <- var.list[sapply(var.list, function(x) !is.null(get(x)))]
  filled.list <- sapply(present.var.list, function(x) { return(create.filled.series(get(x), trunc(get(paste(x, "dates", sep="."))), date.series)) }, simplify=FALSE)

  ## NA masks
  namasks <- list(annual=lapply(filled.list, get.na.mask, date.factors$annual, max.missing.days['annual']), monthly=lapply(filled.list, get.na.mask, date.factors$monthly, max.missing.days['monthly']))
  namasks$annual <- lapply(names(namasks$annual), function(v) { d <- namasks$annual[[v]] * as.numeric(tapply(namasks$monthly[[v]], rep(seq_along(namasks$annual[[v]]), each=12), prod)); dimnames(d) <- dim(d) <- NULL; d })
  names(namasks$annual) <- names(namasks$monthly)

  ## Quantiles
  quantile.dates <- list(var=var.dates)
  days.in.base <- sapply(quantile.dates, get.num.days.in.range, bs.date.range)
  quantiles <- get.var.quantiles(filled.list$var, date.series, bs.date.range, qtiles=var.qtiles)

  return(new("climdexInput", data=filled.list, quantiles=quantiles, namasks=namasks, dates=date.series,base.range=bs.date.range, date.factors=date.factors))
}

marclimdex.getmx <- function(ci, freq=c("monthly","annual")) { stopifnot(!is.null(ci@data$var)); return(suppressWarnings(tapply.fast(ci@data$var, ci@date.factors[[match.arg(freq)]], max, na.rm=TRUE)) * ci@namasks[[match.arg(freq)]]$var )}

marclimdex.getmn <- function(ci, freq=c("monthly","annual")) { stopifnot(!is.null(ci@data$var)); return(suppressWarnings(tapply.fast(ci@data$var, ci@date.factors[[match.arg(freq)]], min, na.rm=TRUE)) * ci@namasks[[match.arg(freq)]]$var )}

marclimdex.hsmx <- function(ci) { return (marclimdex.getmx(ci,freq='monthly')) }
marclimdex.hsax <- function(ci) { return (marclimdex.getmx(ci,freq='annual')) }

marclimdex.hsro <- function(ci, threshold = 2.5) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, threshold, ">") * ci@namasks$annual$var) }

marclimdex.hshi <- function(ci, threshold = 6) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, threshold, ">") * ci@namasks$annual$var) }

marclimdex.fhsro <- function(ci, threshold = 2.5) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, threshold, ">") * 100. / get.jdays(paste(sort(unique(get.years(ci@dates))),'12','31',sep='-')) * ci@namasks$annual$var) }

marclimdex.fhshi <- function(ci, threshold = 6) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, threshold, ">") * 100. / get.jdays(paste(sort(unique(get.years(ci@dates))),'12','31',sep='-')) * ci@namasks$annual$var) }

marclimdex.fhs10p <- function(ci) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, ci@quantiles['q10'], "<") * 100. / get.jdays(paste(sort(unique(get.years(ci@dates))),'12','31',sep='-')) * ci@namasks$annual$var) }

marclimdex.fhs90p <- function(ci) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, ci@quantiles['q90'], ">") * 100. / get.jdays(paste(sort(unique(get.years(ci@dates))),'12','31',sep='-')) * ci@namasks$annual$var) }

marclimdex.hhsdi <- function(ci) {
  return(threshold.exceedance.duration.index(ci@data$var, ci@date.factors$annual, ci@quantiles['q90'], op=">", min.length=2, spells.can.span.years=FALSE) * ci@namasks$annual$var) }

marclimdex.wsmx <- function(ci) { return (marclimdex.getmx(ci,freq='monthly')) }
marclimdex.wsax <- function(ci) { return (marclimdex.getmx(ci,freq='annual')) }

marclimdex.wsb0 <- function(ci, threshold = 0.514) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, threshold, "<") * ci@namasks$annual$var) }

marclimdex.wsb7 <- function(ci, threshold = 14.403) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, threshold, ">") * ci@namasks$annual$var) }

marclimdex.wsb8 <- function(ci, threshold = 17.222) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, threshold, ">") * ci@namasks$annual$var) }

marclimdex.wsb9 <- function(ci, threshold = 20.833) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, threshold, ">") * ci@namasks$annual$var) }

marclimdex.wsb10 <- function(ci, threshold = 24.722) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, threshold, ">") * ci@namasks$annual$var) }

marclimdex.fwsb0 <- function(ci, threshold = 0.514) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, threshold, "<") * 100. / get.jdays(paste(sort(unique(get.years(ci@dates))),'12','31',sep='-')) * ci@namasks$annual$var) }

marclimdex.fwsb7 <- function(ci, threshold = 14.403) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, threshold, ">") * 100. / get.jdays(paste(sort(unique(get.years(ci@dates))),'12','31',sep='-')) * ci@namasks$annual$var) }

marclimdex.fwsb8 <- function(ci, threshold = 17.222) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, threshold, ">") * 100. / get.jdays(paste(sort(unique(get.years(ci@dates))),'12','31',sep='-')) * ci@namasks$annual$var) }

marclimdex.fwsb9 <- function(ci, threshold = 20.833) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, threshold, ">") * 100. / get.jdays(paste(sort(unique(get.years(ci@dates))),'12','31',sep='-')) * ci@namasks$annual$var) }

marclimdex.fwsb10 <- function(ci, threshold = 24.722) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, threshold, ">") * 100. / get.jdays(paste(sort(unique(get.years(ci@dates))),'12','31',sep='-')) * ci@namasks$annual$var) }

marclimdex.fws10p <- function(ci) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, ci@quantiles['q10'], "<") * 100. / get.jdays(paste(sort(unique(get.years(ci@dates))),'12','31',sep='-')) * ci@namasks$annual$var) }

marclimdex.fws90p <- function(ci) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, ci@quantiles['q90'], ">") * 100. / get.jdays(paste(sort(unique(get.years(ci@dates))),'12','31',sep='-')) * ci@namasks$annual$var) }

marclimdex.hwsdi <- function(ci) {
  return(threshold.exceedance.duration.index(ci@data$var, ci@date.factors$annual, ci@quantiles['q90'], op=">", min.length=2, spells.can.span.years=FALSE) * ci@namasks$annual$var) }

marclimdex.lwsdi <- function(ci) {
  return(threshold.exceedance.duration.index(ci@data$var, ci@date.factors$annual, ci@quantiles['q10'], op="<", min.length=2, spells.can.span.years=FALSE) * ci@namasks$annual$var) }

marclimdex.wlmx <- function(ci) { return (marclimdex.getmx(ci,freq='monthly')) }
marclimdex.wlax <- function(ci) { return (marclimdex.getmx(ci,freq='annual')) }
marclimdex.wlmn <- function(ci) { return (marclimdex.getmn(ci,freq='monthly')) }
marclimdex.wlan <- function(ci) { return (marclimdex.getmn(ci,freq='annual')) }

marclimdex.fwln10p <- function(ci) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, ci@quantiles['q10'], "<") * 100. / get.jdays(paste(sort(unique(get.years(ci@dates))),'12','31',sep='-')) * ci@namasks$annual$var) }

marclimdex.fwlx90p <- function(ci) {
  return(number.days.op.threshold(ci@data$var, ci@date.factors$annual, ci@quantiles['q90'], ">") * 100. / get.jdays(paste(sort(unique(get.years(ci@dates))),'12','31',sep='-')) * ci@namasks$annual$var) }

marclimdex.hwldi <- function(ci) {
  return(threshold.exceedance.duration.index(ci@data$var, ci@date.factors$annual, ci@quantiles['q90'], op=">", min.length=2, spells.can.span.years=FALSE) * ci@namasks$annual$var) }
