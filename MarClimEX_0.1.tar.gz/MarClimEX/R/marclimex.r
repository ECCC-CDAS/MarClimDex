## marclimex.r - MarClimEX
## R implementation of MarClimEX using R tcl/tk graphical interface
## ETCCDI core marine climate change/extreme indices
## This program copied some functions from climdex.pcic package
## Last updated by Rodney Chan, May 2016
## Intital version by Rodney Chan, May 2016

## Requires PCICt
library(PCICt)

# Debug use
#source('ecqc.r')
#source('ecui.r')
#source('marcal.r')

## Environment to store objects
marclimex.env <- new.env()

## Lower overhead version of tapply
tapply.fast <- function (X, INDEX, FUN = NULL, ..., simplify = TRUE) {
  FUN <- if (!is.null(FUN))
    match.fun(FUN)

  if(!is.factor(INDEX))
    stop("INDEX must be a factor.")

  if (length(INDEX) != length(X))
    stop("arguments must have same length")

  if (is.null(FUN))
    return(INDEX)

  namelist <- levels(INDEX)
  ans <- lapply(split(X, INDEX), FUN, ...)

  ans <- unlist(ans, recursive = FALSE)
  names(ans) <- levels(INDEX)
  return(ans)
}

## Get NA mask given threshold and split factor
get.na.mask <- function(x, f, threshold) {
  return(c(1, NA)[1 + as.numeric(tapply.fast(is.na(x), f, function(y) { return(sum(y) > threshold) } ))])
}

## Perform indices calulation
IndicesCalculation <- function(climdexinput) {
  ## Prepare file path and file name
  file.path <- marclimex.env$parameter$file.loc
  file.prefix <- marclimex.env$parameter$station

  ## Perform calulation and outut results
  WriteIndice("hsmx", "HsMx", marclimex.env$parameter$hsmx, file.path, file.prefix, climdexinput, monthly = TRUE, round = 5)
  WriteIndice("hsax", "HsAx", marclimex.env$parameter$hsax, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("hsro","HsRo",marclimex.env$parameter$hsro, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("fhsro","fHsRo",marclimex.env$parameter$hsro, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("hshi","HsHi",marclimex.env$parameter$hsro, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("fhshi","fHsHi",marclimex.env$parameter$hsro, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("fhs10p","fHs10p",marclimex.env$parameter$hsro, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("fhs90p","fHs90p",marclimex.env$parameter$hsro, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("hhsdi","HHsDI",marclimex.env$parameter$hhsdi, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)

  WriteIndice("wsmx", "WsMx", marclimex.env$parameter$wsmx, file.path, file.prefix, climdexinput, monthly = TRUE, round = 5)
  WriteIndice("wsax", "WsAx", marclimex.env$parameter$wsax, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("wsb0", "WsB0", marclimex.env$parameter$wsb0, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("wsb7", "WsB7", marclimex.env$parameter$wsb7, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("wsb8", "WsB8", marclimex.env$parameter$wsb8, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("wsb9", "WsB9", marclimex.env$parameter$wsb9, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("wsb10", "WsB10", marclimex.env$parameter$wsb10, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("fwsb0", "fWsB0", marclimex.env$parameter$fwsb0, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("fwsb7", "fWsB7", marclimex.env$parameter$fwsb7, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("fwsb8", "fWsB8", marclimex.env$parameter$fwsb8, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("fwsb9", "fWsB9", marclimex.env$parameter$fwsb9, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("fwsb10", "fWsB10", marclimex.env$parameter$fwsb10, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("fws10p","fWs10p",marclimex.env$parameter$fws10p, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("fws90p","fWs90p",marclimex.env$parameter$fws90p, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("hwsdi", "HWsDI", marclimex.env$parameter$hwsdi, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("lwsdi", "LWsDI", marclimex.env$parameter$lwsdi, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)


  WriteIndice("wlmx", "WlMx", marclimex.env$parameter$wlmx, file.path, file.prefix, climdexinput, monthly = TRUE, round = 5)
  WriteIndice("wlax", "WlAx", marclimex.env$parameter$wlax, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("wlmn", "WlMn", marclimex.env$parameter$wlmx, file.path, file.prefix, climdexinput, monthly = TRUE, round = 5)
  WriteIndice("wlan", "WlAn", marclimex.env$parameter$wlax, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("fwlx90p", "fWlX90p", marclimex.env$parameter$wlax, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("fwln10p", "fWlN10p", marclimex.env$parameter$wlax, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
  WriteIndice("hwldi", "HWlDI", marclimex.env$parameter$wlax, file.path, file.prefix, climdexinput, monthly = FALSE, round = 5)
}

## Operator to select correct climdex.pcic function for each calulation
## Also communicate with ecqc for correct output
WriteIndice <- function(selection, oname, choice, outpath, outname, climdexinput, monthly = FALSE, pcicname = NULL, custom = "", round = NULL) {
  ## Get correct name of corresponding climdex.pcic function
  if(is.null(pcicname)) pcicname <- selection
  if(custom != "") {
    if(grepl("nn", selection)) {
      selection  <- gsub("nn", custom, selection)
    } else if(grepl("mm", selection)) {
      selection <- gsub("mm", custom, selection)
    }
  }
  if(custom != "") custom <- paste(",", custom, sep = "")

  ## If user selected then perform calulation
  if(as.logical(choice)) {
    label <- c(paste("year", oname, sep = " "))
    result <- eval(parse(text = paste("marclimdex.", pcicname, "(climdexinput", custom, ")", sep = "")))
    years <- sort(unique(get.years(climdexinput@dates)))
    ## Also perform monthly results if possible
    if(monthly) {
      result <- matrix(result, ncol = 12, byrow = TRUE)
      label <- c("year jan feb mar apr may jun jul aug sep oct nov dec")
    }
      if(!is.null(round)) result <- round(result, digits = round)
      result <- cbind(years, result)

    ## Output results in table, plot and trend summary
      WriteTable(result, label, paste(outpath, "indices/", outname, "_", oname, ".txt", sep = ""))
      WritePlot(result, paste(outpath, "plots/", outname, "_", oname, ".pdf", sep = ""), main = paste(oname, outname, sep = "   "), xlab = "Year", ylab = toupper(selection))
    }

}

## Prepare dataset for input format of climdex.pcic
ClimdexInput <- function() {
# climdexinput <- cbind(FilterColumn(marclimex.env$data, "var"), SetDates(marclimex.env$data, "var"))
  climdexinput <- climdexInput.raw(FilterColumn(marclimex.env$data, "var"), SetDates(marclimex.env$data, "var"),
                  base.range=c(marclimex.env$parameter$bp.first,marclimex.env$parameter$bp.last), 
                  var.qtiles=c(0.10, 0.90), max.missing.days=c(annual=15, monthly=3), 
                  min.base.data.fraction.present=0.75)
  return(climdexinput)
}

## Creates PCICt dates with correct calendar type
SetDates <- function(dataset, var) {
  cal <- c("gregorian", "365", "360")
  dates <- c(paste(FilterColumn(dataset, var, "year"), FilterColumn(dataset, var, "month"), FilterColumn(dataset, var, "day"), sep = "-"))
  return(as.PCICt(dates, cal = cal[1]))
}

## Perform quality control
QualityControl <- function() {
  ## Prepare file path and file name
  implicit.missing <- -99.9
  file.path <- marclimex.env$parameter$file.loc
  file.prefix <- marclimex.env$parameter$station

  ## Apply missing mask
  marclimex.env$data[marclimex.env$data == marclimex.env$parameter$missing.mark] <- NA
  marclimex.env$data <- sapply(marclimex.env$data, as.character)
  marclimex.env$data[is.na(marclimex.env$data)] <- -99.9
  marclimex.env$data <- data.frame(marclimex.env$data)

  ## Check for Non-numerics
  ## If Non-numerics in first row, then assume it is header
  ## If still fails then give error
  if(any(is.na(data.frame(sapply(marclimex.env$data, AllNumeric))))) {
    marclimex.env$data <- marclimex.env$data[-1, ]
    if(any(is.na(data.frame(sapply(marclimex.env$data, AllNumeric))))) {
      error <- paste("-Caution-", "Non-numeric values in data are flagged", sep = "\n")
      class(error) <- "error"
      AddLog(error, marclimex.env$alertlog, logfile = marclimex.env$logfile)
    }
  }
  ## Invalid dates gives error
  if(any(is.na(SetMissing(marclimex.env$data[,1:3])))) {
    error <- paste("-Caution-", "All values of incorrect dates are flagged", sep = "\n")
    class(error) <- "error"
    AddLog(error, marclimex.env$alertlog, logfile = marclimex.env$logfile)
  }

  ## Clean data before checks
  marclimex.env$data[marclimex.env$data == -99.9] <- NA
  marclimex.env$data <- data.frame(sapply(marclimex.env$data, AllNumeric))
  ## Duplicate dates to NA
  ## Keep the first occurance only
  marclimex.env$data <- QualityCheck(marclimex.env$data, "duplicated(marclimex.env$data[, c('year', 'month', 'day')])", "The values of repeated dates are flagged", list("year", "month", "day", "var"))

  ## Sort and fix dates
  marclimex.env$data <- FixSortDates(marclimex.env$data)
  ## Fill out dates to end of calendar year
  marclimex.env$data <- FillDates(marclimex.env$data)

}

## Remove invalid calender for the plots and NA summary
## Sort the remaining dataset
FixSortDates <- function(dataset) {
  result <- data.frame(sapply(dataset, AllNumeric))
  names(result) <- names(dataset)
  if(any(is.na(result$year))) {
    result <- result[-which(is.na(result$year)), ]
  }
  result <- result[order(result$year, result$month, result$day), ]
  return(result)
}

## Fill dates to correspond with full year and remove leap days as well as erroraeous dates
FillDates <- function(dataset) {
  monthdays <- c(31,29,31,30,31,30,31,31,30,31,30,31)
  startyear <- min(dataset$year, na.rm=T)
  endyear <- max(dataset$year, na.rm=T)
  blanks <- data.frame(cbind(sort(rep(seq(startyear,endyear),366)),rep(rep(seq(1,12),monthdays),(endyear-startyear+1)),rep(c(seq(1,monthdays[1]),seq(1,monthdays[2]),seq(1,monthdays[3]),seq(1,monthdays[4]),seq(1,monthdays[5]),seq(1,monthdays[6]),seq(1,monthdays[7]),seq(1,monthdays[8]),seq(1,monthdays[9]),seq(1,monthdays[10]),seq(1,monthdays[11]),seq(1,monthdays[12])),(endyear-startyear+1)),rep(NA,366*(endyear-startyear+1)),rep(NA,366*(endyear-startyear+1)),rep(NA,366*(endyear-startyear+1))))
  names(blanks) <- names(dataset)
  blankskey <- c(blanks$year*100000+blanks$month*100+blanks$day)
  datakey <- c(dataset$year*100000+dataset$month*100+dataset$day)
  result <- blanks
  keys <- match(datakey,blankskey)
  if(any(is.na(keys))) {
    nokeys <- which(is.na(keys))
    keys <- keys[!is.na(keys)]
    result[keys,"var"] <- dataset[-nokeys,"var"]
  } else {
    result[keys,"var"] <- dataset$var
  }
  result <- data.frame(sapply(result, AllNumeric))
  ## Leap years
  result <- result[-which((result$month == 2 & result$year%%4 != 0 & result$day > 28) | (result$month == 2 & result$year%%4 == 0 & result$year%%100 == 0 & result$year%%400 != 0 & result$day > 28)), ]
  return(result)
}

## Set non-numeric, invalid dates and missing mark to NA
SetMissing <- function(dataset) {
  result <- data.frame(sapply(dataset, AllNumeric))
  names(result) <- names(dataset)
  result[which(result$month > 12 | result$month < 1), ] <- NA
  result[which(result$day > 31 | result$day < 1), ] <- NA
  result[which(result$month == 2 & result$day > 29), ] <- NA
  result[which(result$month == 2 & result$year%%4 != 0 & result$day > 28), ] <- NA
  result[which(result$month == 2 & result$year%%4 == 0 & result$year%%100 == 0 & result$year%%400 != 0 & result$day > 28), ] <- NA
  result[which(result$month == 4 & result$day > 30), ] <- NA
  result[which(result$month == 6 & result$day > 30), ] <- NA
  result[which(result$month == 9 & result$day > 30), ] <- NA
  result[which(result$month == 11 & result$day > 30), ] <- NA
  result[which(result$year < 1), ] <- NA
  result[result == marclimex.env$parameter$missing.mark] <- NA
  result[is.na(result$year), ] <- NA
  result[is.na(result$month), ] <- NA
  result[is.na(result$day), ] <- NA
  flg <- any(is.na(result$year))
  if(!is.na(flg)) {
     flg <- any(is.na(result$month))
     if(!is.na(flg)) {
       flg <- any(is.na(result$day))
       if(!is.na(flg)) {
         return(result)
       }
     }
  }
  return(NA)
}

## Check if dataset has right number of column
## Assume dataset is year, month, day, var
DataCheck <- function() {
  if(ncol(marclimex.env$data) != 4) {
    error <- paste("-Error-", "Dataset formatting is not correct\nIt should be 4 column: 'year month day var'", sep = "\n")
    class(error) <- "try-error"
    return(error)
  }
  #dataset <- data.frame(sapply(marclimex.env$data, AllNumeric))
  #names(marclimex.env$data) <- AssignName(dataset)
  names(marclimex.env$data) <- c("year", "month", "day", "var")
  return("")
}

## Open and read dataset with open file interface
## Supports opening multiple files
OpenFile <- function(suffix) {
  fontstyle <- DefaultFont("")
  name <- tk_choose.files(caption = "Choose input data file(s)", filters = matrix(c("All Readable Files", suffix, "All Files", "*"), ncol = 2, byrow = TRUE))
  ## Pop-up and go back if no file open
  if(length(name) < 1) {
    error <- paste("-Error-", "No file is selected", sep = "\n")
    class(error) <- "try-error"
    return(error)
  ## Multiple file selected, store list, and open first dataset only
  } else if(length(name) > 1) {
    assign("filelist", name, envir = marclimex.env)
    name <- name[1]
  ## Only one file selected
  } else {
    assign("filelist", name, envir = marclimex.env)
  }
  data <- ReadTable(name)
  ## Error when trying to read file
  if(class(data) == "try-error") {
    error <- paste("-Error-", "Unable to open file:", name, sep = "\n")
    class(error) <- "try-error"
    return(error)
  }
  assign("data", data, envir = marclimex.env)
  marclimex.env$parameter$file.in <- name
  assign("entries.file.in", tclVar(as.character(name)), envir = marclimex.env)
  return("")
}

## Create output folders
## The output folder is under indices
SetOutputFolders <- function(path) {
  MakeFolder(path, "indices")
  MakeFolder(path, "plots")
  if(is.na(marclimex.env$logfile)) {
    assign("logfile", paste(path, paste("log.", gsub("-", "", gsub(":", "", gsub("[[:space:]]", ".", Sys.time()))), ".txt", sep = ""), sep = ""), envir = marclimex.env)
  }
}

## Initial values for input parameters
SetParameter <- function() {
  parameter <- list("", "", "", -99.9, 1990, 2010, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1)
  names(parameter) <- list("file.in", "file.loc", "station", "missing.mark", "bp.first", "bp.last", "indices.selection", "hsmx", "hsax", "hsro", "hshi", "fhsro", "fhshi", "fhs90p", "fhs10p", "hhsdi", "wsmx", "wsax", "wsb0", "wsb7", "wsb8", "wsb9", "wsb10",  "fwsb0", "fwsb7", "fwsb8", "fwsb9", "fwsb10", "fws90p", "fws10p", "hwsdi", "lwsdi", "wlmx", "wlmn", "wlax", "wlan", "fwlx90p", "fwln10p", "hwldi", "sssmx", "sssme", "sssax", "sssae", "sss90p")
  assign("parameter", parameter, envir = marclimex.env)
}

## Get indices calulation parameters from user input
GetICParameter <- function() {
  marclimex.env$parameter$file.in <- as.character(tclvalue(marclimex.env$entries.file.in))
  marclimex.env$parameter$file.loc <- as.character(tclvalue(marclimex.env$entries.file.loc))
  marclimex.env$parameter$missing.mark <- as.character(tclvalue(marclimex.env$entries.missing.mark))
  marclimex.env$parameter$bp.first <- as.numeric(tclvalue(marclimex.env$entries.bp.first))
  marclimex.env$parameter$bp.last <- as.numeric(tclvalue(marclimex.env$entries.bp.last))
}

## Get indices calulation selections from user input
GetICSelection <- function() {
  marclimex.env$parameter$indices.selection <- as.numeric(tclvalue(marclimex.env$entries.indices.selection))
  ClearICSelection()
  if(marclimex.env$parameter$indices.selection==1) {
    marclimex.env$parameter$hsmx <- 1
    marclimex.env$parameter$hsax <- 1
    marclimex.env$parameter$hsro <- 1
    marclimex.env$parameter$hshi <- 1
    marclimex.env$parameter$fhsro <- 1
    marclimex.env$parameter$fhshi <- 1
    marclimex.env$parameter$fhs90p <- 1
    marclimex.env$parameter$fhs10p <- 1
    marclimex.env$parameter$hhsdi <- 1
  }  else if(marclimex.env$parameter$indices.selection==2) {
    marclimex.env$parameter$wsmx <- 1
    marclimex.env$parameter$wsax <- 1
    marclimex.env$parameter$wsb0 <- 1
    marclimex.env$parameter$wsb7 <- 1
    marclimex.env$parameter$wsb8 <- 1
    marclimex.env$parameter$wsb9 <- 1
    marclimex.env$parameter$wsb10 <- 1
    marclimex.env$parameter$fwsb0 <- 1
    marclimex.env$parameter$fwsb7 <- 1
    marclimex.env$parameter$fwsb8 <- 1
    marclimex.env$parameter$fwsb9 <- 1
    marclimex.env$parameter$fwsb10 <- 1
    marclimex.env$parameter$fws90p <- 1
    marclimex.env$parameter$fws10p <- 1
    marclimex.env$parameter$hwsdi <- 1
    marclimex.env$parameter$lwsdi <- 1
  }  else if(marclimex.env$parameter$indices.selection==3) {
    marclimex.env$parameter$wlmx <- 1
    marclimex.env$parameter$wlmn <- 1
    marclimex.env$parameter$wlax <- 1
    marclimex.env$parameter$wlan <- 1
    marclimex.env$parameter$fwlx90p <- 1
    marclimex.env$parameter$fwln10p <- 1
    marclimex.env$parameter$hwldi <- 1
    marclimex.env$parameter$sssmx <- 1
    marclimex.env$parameter$sssme <- 1
    marclimex.env$parameter$sssax <- 1
    marclimex.env$parameter$sssae <- 1
    marclimex.env$parameter$sss90p <- 1
  }
}

## Reset indices calulation selections
ClearICSelection <- function() {
  marclimex.env$parameter$hsmx <- 0
  marclimex.env$parameter$hsax <- 0
  marclimex.env$parameter$hsro <- 0
  marclimex.env$parameter$hshi <- 0
  marclimex.env$parameter$fhsro <- 0
  marclimex.env$parameter$fhshi <- 0
  marclimex.env$parameter$fhs90p <- 0
  marclimex.env$parameter$fhs10p <- 0
  marclimex.env$parameter$hhsdi <- 0
  marclimex.env$parameter$wsmx <- 0
  marclimex.env$parameter$wsax <- 0
  marclimex.env$parameter$wsb0 <- 0
  marclimex.env$parameter$wsb7 <- 0
  marclimex.env$parameter$wsb8 <- 0
  marclimex.env$parameter$wsb9 <- 0
  marclimex.env$parameter$wsb10 <- 0
  marclimex.env$parameter$fwsb0 <- 0
  marclimex.env$parameter$fwsb7 <- 0
  marclimex.env$parameter$fwsb8 <- 0
  marclimex.env$parameter$fwsb9 <- 0
  marclimex.env$parameter$fwsb10 <- 0
  marclimex.env$parameter$fws90p <- 0
  marclimex.env$parameter$fws10p <- 0
  marclimex.env$parameter$hwsdi <- 0
  marclimex.env$parameter$lwsdi <- 0
  marclimex.env$parameter$wlmx <- 0
  marclimex.env$parameter$wlmn <- 0
  marclimex.env$parameter$wlax <- 0
  marclimex.env$parameter$wlan <- 0
  marclimex.env$parameter$fwlx90p <- 0
  marclimex.env$parameter$fwln10p <- 0
  marclimex.env$parameter$hwldi <- 0
  marclimex.env$parameter$sssmx <- 0
  marclimex.env$parameter$sssme <- 0
  marclimex.env$parameter$sssax <- 0
  marclimex.env$parameter$sssae <- 0
  marclimex.env$parameter$sss90p <- 0
}

## Skip some indices calulations if dataset does not allow it
FilterICSelection <- function(dataset) {
  bp <- dataset[which(dataset$year >= marclimex.env$parameter$bp.first & dataset$year <= marclimex.env$parameter$bp.last), ]
  threshold <- (marclimex.env$parameter$bp.last - marclimex.env$parameter$bp.first + 1) * 365 * (1 - 0.25)
  if(sum(!is.na(bp$var)) <= threshold) {
    marclimex.env$parameter$fhs90p <- 0
    marclimex.env$parameter$fhs10p <- 0
    marclimex.env$parameter$hhsdi <- 0
    marclimex.env$parameter$fws90p <- 0
    marclimex.env$parameter$fws10p <- 0
    marclimex.env$parameter$hwsdi <- 0
    marclimex.env$parameter$lwsdi <- 0
    marclimex.env$parameter$fwlx90p <- 0
    marclimex.env$parameter$fwln10p <- 0
    marclimex.env$parameter$hwldi <- 0
    AddLog("NA in base period is more than 25%, skips indices calulations for those relating with the base period", marclimex.env$alertlog, logfile = marclimex.env$logfile)
  }
}

## Save indices calulation parameters from user input
SaveICSelection <- function() {
  result <- c(marclimex.env$parameter$hsmx,marclimex.env$parameter$hsax,marclimex.env$parameter$hsro,marclimex.env$parameter$hshi,marclimex.env$parameter$fhsro,marclimex.env$parameter$fhshi,marclimex.env$parameter$fhs90p,marclimex.env$parameter$fhs10p,marclimex.env$parameter$hhsdi,marclimex.env$parameter$wsmx,marclimex.env$parameter$wsax,marclimex.env$parameter$wsb0,marclimex.env$parameter$wsb7,marclimex.env$parameter$wsb8,marclimex.env$parameter$wsb9,marclimex.env$parameter$wsb10,marclimex.env$parameter$fwsb0,marclimex.env$parameter$fwsb7,marclimex.env$parameter$fwsb8,marclimex.env$parameter$fwsb9,marclimex.env$parameter$fwsb10,marclimex.env$parameter$fws90p,marclimex.env$parameter$fws10p,marclimex.env$parameter$hwsdi,marclimex.env$parameter$lwsdi,marclimex.env$parameter$wlmx,marclimex.env$parameter$wlmn,marclimex.env$parameter$wlax,marclimex.env$parameter$wlan,marclimex.env$parameter$fwlx90p,marclimex.env$parameter$fwln10p,marclimex.env$parameter$hwldi,marclimex.env$parameter$sssmx,marclimex.env$parameter$sssme,marclimex.env$parameter$sssax,marclimex.env$parameter$sssae,marclimex.env$parameter$sss90p)
  return(result)
}

## Reload indices calulation parameters from user input
LoadICSelection <- function(para) {
  marclimex.env$parameter$hsmx <- para[1]
  marclimex.env$parameter$hsax <- para[2]
  marclimex.env$parameter$hsro <- para[3]
  marclimex.env$parameter$hshi <- para[4]
  marclimex.env$parameter$fhsro <- para[5]
  marclimex.env$parameter$fhshi <- para[6]
  marclimex.env$parameter$fhs90p <- para[7]
  marclimex.env$parameter$fhs10p <- para[8]
  marclimex.env$parameter$hhsdi <- para[9]
  marclimex.env$parameter$wsmx <- para[10]
  marclimex.env$parameter$wsax <- para[11]
  marclimex.env$parameter$wsb0 <- para[12]
  marclimex.env$parameter$wsb7 <- para[13]
  marclimex.env$parameter$wsb8 <- para[14]
  marclimex.env$parameter$wsb9 <- para[15]
  marclimex.env$parameter$wsb10 <- para[16]
  marclimex.env$parameter$fwsb0 <- para[17]
  marclimex.env$parameter$fwsb7 <- para[18]
  marclimex.env$parameter$fwsb8 <- para[19]
  marclimex.env$parameter$fwsb9 <- para[20]
  marclimex.env$parameter$fwsb10 <- para[21]
  marclimex.env$parameter$fws90p <- para[22]
  marclimex.env$parameter$fws10p <- para[23]
  marclimex.env$parameter$hwsdi <- para[24]
  marclimex.env$parameter$lwsdi <- para[25]
  marclimex.env$parameter$wlmx <- para[26]
  marclimex.env$parameter$wlmn <- para[27]
  marclimex.env$parameter$wlax <- para[28]
  marclimex.env$parameter$wlan <- para[29]
  marclimex.env$parameter$fwlx90p <- para[30]
  marclimex.env$parameter$fwln10p <- para[31]
  marclimex.env$parameter$hwldi <- para[32]
  marclimex.env$parameter$sssmx <- para[33]
  marclimex.env$parameter$sssme <- para[34]
  marclimex.env$parameter$sssax <- para[35]
  marclimex.env$parameter$sssae <- para[36]
  marclimex.env$parameter$sss90p <- para[37]
}

## Parse user inputted indices calulation parameters
ParseICParameter <- function(dataset) {
  firstyear <- min(dataset["year"], na.rm = TRUE)
  lastyear <- max(dataset["year"], na.rm = TRUE)

  ## Special character then file path valid
  error <- ParseError("[[:alnum:]_.:/\b\\-]*", as.character(tclvalue(marclimex.env$entries.file.in)), "Input data path must not contain any of these character\n! \" # $ % & \' ( ) * + , ; < = > ? @ [ ] ^ ` { | } ~")
  if(!file.exists(as.character(tclvalue(marclimex.env$entries.file.in)))) {
    error <- paste("-Error-", "Input data does not exist", "Please check data location", sep = "\n")
    class(error) <- "try-error"
  }
  if(class(error) == "try-error") return(error)
  error <- ParseError("[[:alnum:]_:/\b\\-]*", as.character(tclvalue(marclimex.env$entries.file.loc)), "Output directory must not contain any of these character\n! \" # $ % & \' ( ) * + , . ; < = > ? @ [ ] ^ ` { | } ~")
  if(class(error) == "try-error") return(error)
  filepath <- as.character(tclvalue(marclimex.env$entries.file.loc))
  filepath <- substr(filepath, 1, nchar(filepath) - 1)
  if(!file.exists(filepath)) {
    error <- paste("-Error-", "Output directory does not exist", "Please create output folder first", sep = "\n")
    class(error) <- "try-error"
  }
  if(substr(as.character(tclvalue(marclimex.env$entries.file.loc)), nchar(as.character(tclvalue(marclimex.env$entries.file.loc))), nchar(as.character(tclvalue(marclimex.env$entries.file.loc)))) != "/") marclimex.env$entries.file.loc <- tclVar(paste(as.character(tclvalue(marclimex.env$entries.file.loc)), "/", sep = ""))
  if(class(error) == "try-error") return(error)

  ## Alphanumericals, dot and hyphen only
  error <- ParseError("[[:alnum:]_.\\-]*", as.character(tclvalue(marclimex.env$entries.station)), "Station name must not contain any of these character\n! \" # $ % & \' ( ) * + , / : ; < = > ? @ [ \\ ] ^ ` { | } ~")
  if(class(error) == "try-error") return(error)

  ## No special character, no spaces
  error <- ParseError("[[:graph:]]*", as.character(tclvalue(marclimex.env$entries.missing.mark)), "No spaces for missing marker")
  if(class(error) == "try-error") return(error)

  ## Integers
  error <- ParseError("[[:digit:]]*", as.character(tclvalue(marclimex.env$entries.bp.first)), "First year of base period must be a positive number")
  if(class(error) == "try-error") return(error)
  error <- ParseRange(as.numeric(tclvalue(marclimex.env$entries.bp.first)), firstyear, lastyear, paste("Base Period must be between ", firstyear, " and ", lastyear, sep = ""))
  if(class(error) == "try-error") return(error)
  error <- ParseError("[[:digit:]]*", as.character(tclvalue(marclimex.env$entries.bp.last)), "Last year of base period must be a positive number")
  if(class(error) == "try-error") return(error)
  error <- ParseReverse(as.numeric(tclvalue(marclimex.env$entries.bp.last)), as.numeric(tclvalue(marclimex.env$entries.bp.first)), "Last year must be after first year of base period")
  if(class(error) == "try-error") return(error)
  error <- ParseRange(as.numeric(tclvalue(marclimex.env$entries.bp.last)), firstyear, lastyear, paste("Base Period must be between ", firstyear, " and ", lastyear, sep = ""))
  if(class(error) == "try-error") return(error)

  ## Radio button check
  error <- ParseError("[1-3]{1}", as.character(tclvalue(marclimex.env$entries.indices.selection)), "must be 1 (Hs), 2 (Ws) or 3 (Wl)")
  if(class(error) == "try-error") return(error)
}

## Create user interface for title screen
StartTitle <- function() {
  font <- GetFont()
  main <- tktoplevel()
  assign("main", main, envir = marclimex.env)
  tkwm.title(main, "MarClimEX")
  MakeLabel(main, "Start MarClimEX", fontstyle = font$heading, padx = 170, pady = 75)
  MakeButton(main, "Run MarClimEX", PrepIC, width = 30)
  MakeButton(main, "Exit", function()Quit("main", marclimex.env), width = 30)
  MakeLabel(main, "", fontstyle = font$heading)
  assign("logfile", NA, envir = marclimex.env)
}

## Create user interface for indices calulation
StartIC <- function() {
  font <- GetFont()
  main <- tktoplevel()
  assign("main", main, envir = marclimex.env)

  ## Title
  tkwm.title(main, "MarClimEX")
  MakeLabel(main, "Set Parameters for Indices Calculation", fontstyle = font$heading1, sticky = "w")
  MakeLabel(main, "", fontstyle = font$normal)

  ## User input
  top <- tkframe(main)
  tkgrid(top)
  MakeLabel(top, "Output files location : ", fontstyle = font$normal, sticky = "e")
  MakeEntry(top, marclimex.env$parameter$file.loc, "entries.file.loc", row = 0, column = 1, sticky = "w", env = marclimex.env)
  if(length(marclimex.env$filelist) == 1) {
    MakeLabel(top, "Station name or code : ", fontstyle = font$normal, sticky = "e")
    MakeEntry(top, marclimex.env$parameter$station, "entries.station", row = 1, column = 1, sticky = "w", env = marclimex.env)
  }
  MakeLabel(top, "Missing marker : ", fontstyle = font$normal, row = 2, column = 0, sticky = "e")
  MakeEntry(top, marclimex.env$parameter$missing.mark, "entries.missing.mark", row = 2, column = 1, sticky = "w", width = 10, env = marclimex.env)
  MakeLabel(top, "Base period : ", fontstyle = font$normal, sticky = "e")
  MakeICEntry(top, list("First year", "Last year"), list("bp.first", "bp.last"), fontstyle = font$normal, row = 3, column = 1)
  MakeLabel(top, "Indices Selection : ", fontstyle = font$normal, sticky = "e")
  MakeRadio(top, marclimex.env$parameter$indices.selection, list("Hs", "Ws", "Wl"), "entries.indices.selection", fontstyle = font$normal, row = 4, column = 1, sticky = "w", env = marclimex.env)

  MakeLabel(top, "", fontstyle = font$normal)
  MakeLabel(top, "Extreme Wave Height Indices (Hs) : ", fontstyle = font$normal, sticky = "e")
  MakeLabel(top, "HsMx, HsAx, HsRo, HsHi, fHsRo, fHsHi, fHs90p, fHs10p", fontstyle = font$normal, row = 6, column = 1, sticky = "w")
  MakeLabel(top, "HHsDI", fontstyle = font$normal, row = 7, column = 1, sticky = "w")
  MakeLabel(top, "Extreme Wind Indices (Ws) : ", fontstyle = font$normal, sticky = "e")
  MakeLabel(top, "WsMx, WsAx, WsB0, WsB7, WsB8, WsB9, WsB10", fontstyle = font$normal, row = 8, column = 1, sticky = "w")
  MakeLabel(top, "fWsB0, fWsB7, fWsB8, fWsB9, fWsB10, fWs90p", fontstyle = font$normal, row = 9, column = 1, sticky = "w")
  MakeLabel(top, "fWs10p, HWsDI, LWsDI", fontstyle = font$normal, row = 10, column = 1, sticky = "w")
  MakeLabel(top, "Extreme Water Level Indices (Wl) : ", fontstyle = font$normal, sticky = "e")
  MakeLabel(top, "WlMx, WlMx, WlAx, WlAx, fWlX90p, fWlN10p, HWlDI", fontstyle = font$normal, row = 11, column = 1, sticky = "w")
  MakeLabel(top, "SSSMx, SSSMe, SSSAx, SSSAe, SSS90p", fontstyle = font$normal, row = 12, column = 1, sticky = "w")

  ## Action buttons, OK or Quit
  MakeLabel(main, "", fontstyle = font$normal)
  bottom <- tkframe(main)
  tkgrid(bottom)
  MakeButton(bottom, "Quit", PrepMain, sticky = "w")
  MakeButton(bottom, "Perform Indices Calculation", PerformIC, row = 0, column = 1, width = 30, sticky = "e")
  MakeLabel(main, "", fontstyle = font$normal)

  ## Log window
  log <- tkframe(main)
  tkgrid(log)
  MakeLog(log, "alertlog", env = marclimex.env)
  AddLog(paste("Loaded ", length(marclimex.env$filelist)," file(s)", sep = ""), marclimex.env$alertlog, logfile = marclimex.env$logfile)
  for(i in 1:length(marclimex.env$filelist)) {
    AddLog(paste(i, " - ", marclimex.env$filelist[i], sep = ""), marclimex.env$alertlog, logfile = marclimex.env$logfile)
  }
}

## Prepare for indices calulation user interface
## Load datasets
## Assume datasets passed quality control
PrepIC <- function() {
  error <- PrepData(suffix = ".txt .csv")
  if(MakeAlert(error)) return()
  marclimex.env$parameter$file.loc <- GetFileLoc(marclimex.env$parameter$file.in)
  tkmessageBox(message = paste("Load data file: ", marclimex.env$parameter$file.in, "Click OK to continue", sep = "\n"))
  Quit("main", marclimex.env)
  StartIC()
}

## Read and prepare datasets
PrepData <- function(name = NULL, suffix = ".csv") {
  if(is.null(name)) {
    ## Open file select interface
    error <- OpenFile(suffix)
    if(class(error) == "try-error") {
    return(error)
    }
  } else {
    ## Read dataset
    dataset <- ReadTable(name)
    if(class(dataset) == "try-error") {
      error <- paste("-Error-", "Unable to open file:", name, sep = "\n")
      class(error) <- "try-error"
      return(error)
    }
    ## Get dataset, file name and file path
    marclimex.env$data <- dataset
    marclimex.env$parameter$file.in <- name
    marclimex.env$entries.file.in <- tclVar(as.character(name))
  }
  error <- DataCheck()
  if(class(error) == "try-error") {
    return(error)
  }
  ## Get output file name
  marclimex.env$parameter$station <- GetFileName(marclimex.env$parameter$file.in)
  marclimex.env$entries.station <- tclVar(GetFileName(marclimex.env$parameter$file.in)) 
  return("")
}

## Initiate indices calulations for all selected datasets
PerformIC <- function() {
  MakeProgress("bar", title = "Processing Indices Calulations", message = "Initializing indices calculations", env = marclimex.env)
  good <- 0
  ## For all selected files
  for(i in 1:length(marclimex.env$filelist)) {
    ## Get parameters
    GetICParameter()
    GetICSelection()
    ## Setup output folders
    SetOutputFolders(marclimex.env$parameter$file.loc)
    UpdateProgress(marclimex.env$bar, i/length(marclimex.env$filelist), paste("Processing file ", i, "/", length(marclimex.env$filelist), ": ", marclimex.env$filelist[i], sep = ""))
    eflag <- 0
    if(!(marclimex.env$parameter$file.in == marclimex.env$filelist[1] & i == 1)) {
      error <- PrepData(marclimex.env$filelist[i])
      if(AddLog(error, marclimex.env$alertlog, logfile = marclimex.env$logfile)) {
        eflag <- 1
      } else {
        marclimex.env$data <- SetMissing(marclimex.env$data)
      }
    }
    if(i > 1) {
      LoadICSelection(icpara)
    } else {
      icpara <- SaveICSelection()
    }
    if(length(marclimex.env$data) != 4) eflag <- 1
    FilterICSelection(marclimex.env$data)
    if(as.logical(eflag)) {
      AddLog("FAILED", marclimex.env$alertlog, logfile = marclimex.env$logfile)
      AddLog(paste(i , " out of ", length(marclimex.env$filelist), " file(s) FAILED: ", marclimex.env$filelist[i], sep = ""), marclimex.env$alertlog, logfile = marclimex.env$logfile)
      next()
    }
    ## Parse parameters
    error <- ParseICParameter(marclimex.env$data)
    if(AddLog(error, marclimex.env$alertlog, logfile = marclimex.env$logfile)) {
      AddLog("FAILED", marclimex.env$alertlog, logfile = marclimex.env$logfile)
      AddLog(paste(i , " out of ", length(marclimex.env$filelist), " file(s) FAILED: ", marclimex.env$filelist[i], sep = ""), marclimex.env$alertlog, logfile = marclimex.env$logfile)
      next()
    }
    ## Perform indices calulations
    climdexinput <- ClimdexInput()
    IndicesCalculation(climdexinput)
    AddLog(paste(i , " out of ", length(marclimex.env$filelist), " file(s) done: ", marclimex.env$filelist[i], sep = ""), marclimex.env$alertlog, logfile = marclimex.env$logfile)
    good <- good + 1
  }
  AddLog(paste("Successful in ", good, "/", length(marclimex.env$filelist), " files", sep = ""), marclimex.env$alertlog, logfile = marclimex.env$logfile)
  AddLog("Indices Calculation complete", marclimex.env$alertlog, logfile = marclimex.env$logfile)
  AddLog("Press Quit to exit", marclimex.env$alertlog, logfile = marclimex.env$logfile)
  CloseProgress(marclimex.env$bar)
}

## Prepare for main title
## Close previous window
PrepMain <- function() {
  Quit("main", marclimex.env)
  StartTitle()
}

## Shortcut to make compound label and entry box in indices calulation user interface
MakeICEntry <- function(frame, message, initial, fontstyle = NULL, row = NULL, column = -1, padx = 0, pady = 0, width = 10) {
  top <- tkframe(frame)
  fontstyle <- DefaultFont(fontstyle)
  counter <- -1
  num <- 1:length(initial)
  for(i in num) {
    counter <- counter+1
    MakeLabel(top, as.character(message[i]), fontstyle = fontstyle, sticky = "e", row = 0, column = counter, width = 10)
    counter <- counter+1
    name <- paste("entries.", initial[i], sep = "")
    MakeEntry(top, as.character(marclimex.env$parameter[match(initial[i], names(marclimex.env$parameter))]), name, row = 0, column = counter, sticky = "w", width = width, env = marclimex.env)
  }
  DisplayObject(top, row, column, padx, pady, "")
}

## Start MarClimEX
marclimex.start <- function() {
  options(warn = 2)
  SetFont()
  SetParameter()
  StartTitle()
}
