R CMD Sweave manual.Rnw
pdflatex manual.tex
#latex manual.tex
#dvips manual
