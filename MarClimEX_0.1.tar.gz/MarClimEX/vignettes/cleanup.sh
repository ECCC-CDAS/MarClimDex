rm manual.aux
rm manual.log
rm manual.out
rm manual.pdf
rm manual.tex
rm manual.toc
